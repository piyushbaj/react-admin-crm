import React, { Component } from 'react';


class chat extends Component {
  render() {
    return (
      <div className="App">
        <h1> Inventory  </h1>
           
           
      </div>
    );
  }
}

export default chat;
