import React from 'react';
import Dashboard from './dashboard';
import authProvider from './authProvider';
import { Admin, Resource } from 'react-admin';
import jsonServerProvider from 'ra-data-json-server';
import { UserList } from './users';
import { PostList, PostEdit, Postorder ,Postinventory,Postcustomer, Postseller} from './posts';
// import OverallInventory from './overallInventory';
// import PostIcon from '@material-ui/icons/Book';
import UserIcon from '@material-ui/icons/Group';
// import Payment from './payment.js';
// import Account from './account.js';
// import Help from './help.js';
// import Inventory from './inventory.js';
// import Inventoryreport from './inventoryreport';
// import Orders from './orders';
// import Ordersreport from './ordersreport';
// import Overallorders from './overallorders';
// import Customer from './customer';
// import Customerreport from './customerreport';
// import Sellerinfo from './sellerinfo';
// import SellerinfoReport from './sellerinforeport';
// import simpleRestProvider from 'ra-data-simple-rest';
import addUploadFeature from './addUploadFeature';
const dataProvider1 = jsonServerProvider('http://jsonplaceholder.typicode.com');
const uploadCapableDataProvider = addUploadFeature(dataProvider1);

//<Resource name="posts" list={PostList} edit={PostEdit} create={Postcustomer} icon={PostIcon}/>

//const dataProvider = require('./data.json');
//console.log(dataProvider);

const dataProvider = jsonServerProvider('http://jsonplaceholder.typicode.com');
//const dataProvider = jsonServerProvider('http://www.mocky.io/v2/5c6aaec5330000652d7f4c76');

const App = () =>
(


<Admin dashboard={Dashboard} authProvider={authProvider} dataProvider={dataProvider} dataProvider={uploadCapableDataProvider}>


        <Resource name="users" list={UserList} create={Postorder} icon={UserIcon} />
          
          <Resource name="inventory" list={PostList} edit={PostEdit} create={Postinventory} icon={UserIcon} />
          <Resource name="inventory report" list={PostList} edit={PostEdit} create={Postinventory} icon={UserIcon} />
            <Resource name="Overall Inventory" list={PostList} edit={PostEdit} create={Postinventory} icon={UserIcon} />
            <Resource name="Orders" list={PostList} edit={PostEdit} create={Postorder} icon={UserIcon} />
            <Resource name="Order Report" list={PostList} edit={PostEdit} create={Postorder} icon={UserIcon} />
            <Resource name="Overall Orders" list={PostList} edit={PostEdit} create={Postorder} icon={UserIcon} />
            <Resource name="seller information " list={PostList} edit={PostEdit} create={Postseller} icon={UserIcon} />
            <Resource name="Seller information report" list={PostList} edit={PostEdit} create={Postseller} icon={UserIcon} />
            <Resource name="Customers" list={PostList} edit={PostEdit} create={Postcustomer} icon={UserIcon} />
            <Resource name="Customer Report" list={PostList} edit={PostEdit} create={Postcustomer} icon={UserIcon} />

          <Resource name="help" list={PostList} edit={PostEdit} create={Postcustomer} icon={UserIcon} />
    </Admin>
);

export default App;

