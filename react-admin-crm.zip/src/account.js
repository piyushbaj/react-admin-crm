import React, { Component } from 'react';


class account extends Component {
  render() {
    return (
      <div className="App">
        <h1> account section!! </h1>

      </div>
    );
  }
}

export default account;
