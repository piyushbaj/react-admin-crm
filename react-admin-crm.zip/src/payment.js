import React, { Component } from 'react';


class Payment extends Component {
  render() {
    return (
      <div className="App">
        <h1> payments </h1>

      </div>
    );
  }
}

export default Payment;
