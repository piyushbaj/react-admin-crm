import React from 'react';
import { List, NumberField,Datagrid, TextField, DateField,ReferenceField,Filter, EditButton ,Edit,SimpleForm,DisabledInput,ReferenceInput,SelectInput,TextInput,Create,LongTextInput} from 'react-admin';






export const PostList = props => (
  <List {...props} filters={<PostFilter />}>

        <Datagrid>
        <TextField source="id" />
            <ReferenceField source="userId" reference="users">

<TextField source="name" />

            </ReferenceField>
              <TextField source="title" />
            <EditButton />
        </Datagrid>
    </List>
);



const PostTitle = ({ record }) => {
    return <span>Post {record ? `"${record.title}"` : ''}</span>;
};

export const PostEdit = props => (
  <Edit title={<PostTitle />} {...props}>
        <SimpleForm>
           <DisabledInput source="id" />
            <ReferenceInput source="userId" reference="users">
               <SelectInput optionText="name" />
            </ReferenceInput>
            <TextInput source="title" />
           <LongTextInput source="body" />
        </SimpleForm>
    </Edit>
);


export const Postorder = props => (
    <Create {...props}>
        <SimpleForm>
      <ReferenceInput source="userId" reference="users">
                <SelectInput optionText="name" />
            </ReferenceInput>
            <TextInput source="customer id" />
            <LongTextInput source="customer name" />
            <LongTextInput source="customer address" />
            <LongTextInput source="Customer Contact no"/>
            <DateField source="publication_date" />   
            <TextInput source="product id" />
            <LongTextInput source="product name" />
            <TextInput source="selling price" />
            <TextInput source="Quantity" />
            <TextInput source="Total billing amount" />
            <TextInput source="seller entity name" />
            <TextInput source="seller user id" />
            <TextInput source="Shipping status" />
            <TextInput source="payment to seller" />
            

        </SimpleForm>
    </Create>
);


export const Postinventory = props => (
    <Create {...props}>
        <SimpleForm>
      
            <LongTextInput source="product name" />
            <LongTextInput source="product Description" />
            <ReferenceInput source="userId" reference="users"   >
                <SelectInput optionText="category" />
            </ReferenceInput>
           
            <TextInput source="price" />
            <LongTextInput source="Stock(Number of Units)" />
            <TextInput source="videos" />
            <TextInput source="seller_name" />
            <TextInput source="stock status" />
            <TextInput source="seller entity name" />
            <TextInput source="seller user id" />
            <TextInput source="Stock status" />
            <TextInput source="Image upload" />

        </SimpleForm>
    </Create>
);

export const Postseller = props => (
    <Create {...props}>
        <SimpleForm>
      
            <LongTextInput source="seller entity name" />
            <LongTextInput source="Seller user id" />
            <ReferenceInput source="userId" reference="users"   >
                <SelectInput optionText="Poc name" />
            </ReferenceInput>
           
            <TextInput source="Pic phone number" />
            <LongTextInput source="Seller pickup address" />
            <TextInput source="Seller email id" />
        
        </SimpleForm>
    </Create>
);

export const Postcustomer = props => (
    <Create {...props}>
        <SimpleForm>
      
            <LongTextInput source="name" />
            <LongTextInput source="Customer id" />
            <TextInput source="Phone no " />
            <TextInput source="Address 1" />
            <LongTextInput source="Address 2" />
            <TextInput source="Email" />
            
        </SimpleForm>
    </Create>
);


const PostFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Search" source="q" alwaysOn />
        <ReferenceInput label="User" source="userId" reference="users" allowEmpty>
            <SelectInput optionText="name" />
        </ReferenceInput>
    </Filter>
);



