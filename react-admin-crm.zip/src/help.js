import React, { Component } from 'react';


class help extends Component {
  render() {
    return (
      <div className="App">
        <h1> Help </h1>

      </div>
    );
  }
}

export default help;
